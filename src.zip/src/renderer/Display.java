package renderer;

import renderer.input.ClickType;
import renderer.input.Mouse;
import renderer.point.MyPoint;
import renderer.point.PointConverter;
import renderer.shapes.MyPolygon;
import renderer.shapes.Tetrahedron;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;

public class Display extends Canvas implements  Runnable{

    private static final long serialVersionUID = 1L;

    private Thread thread;
    private JFrame frame;
    private JPanel panel;
    private JLabel instructions = new JLabel("LEFT MOUSE CLICK: TO ROTATE SHAPE ON Y AND Z AXIS  " +
             "  RIGHT MOUSE CLICK: TO ROTATE ON THE X AXIS  " +
             "  SCROLL: TO ZOOM IN AND OUT ON OBJECT", JLabel.CENTER);

    private static  String title = "3D Renderer";
    public static final int WIDTH = 1000; // constant
    public static final int HEIGHT = 600;
    private static boolean running = false;

    private Tetrahedron tetra;
    private Mouse mouse;

    public Display () {
        this.frame = new JFrame();
        this.panel = new JPanel(new BorderLayout());

        frame.add(panel);

        Dimension size = new Dimension(WIDTH, HEIGHT);
        this.setPreferredSize(size);

        this.mouse = new Mouse();
        this.addMouseListener(this.mouse);
        this.addMouseMotionListener(this.mouse);
        this.addMouseWheelListener(this.mouse);
    }

    public static void main (String[] args) {
        Display display = new Display();

        display.frame.setTitle(title);
        display.panel.add(display, BorderLayout.NORTH);
        display.panel.add(display.instructions, BorderLayout.SOUTH);
        display.frame.pack();
        display.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        display.frame.setLocationRelativeTo(null);
        display.frame.setResizable(false);
        display.frame.setVisible(true);

        display.start();

    }

    public synchronized void start () {
        running = true;
        this.thread = new Thread(this, "renderer.Display");

        this.thread.start();
    }

    public synchronized void stop () {
        running = false;

        try {
            this.thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        long timer = System.currentTimeMillis();
        final double ns = 1000000000.0 / 60;
        double delta = 0;
        int frames = 0;

        init();

        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;

            while (delta >= 1) {
                update();
                delta--;
                render();
                frames++;
            }


            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                this.frame.setTitle(title + " | " + frames + " fps");
                frames = 0;
            }
        }

        stop();

    }

    private void init () {
        int s = 100;
        MyPoint p1 = new MyPoint(s/2, -s/2, -s/2);
        MyPoint p2 = new MyPoint(s/2, s/2, -s/2);
        MyPoint p3 = new MyPoint(s/2, s/2, s/2);
        MyPoint p4 = new MyPoint(s/2, -s/2, s/2);
        MyPoint p5 = new MyPoint(-s/2, -s/2, -s/2);
        MyPoint p6 = new MyPoint(-s/2, s/2, -s/2);
        MyPoint p7 = new MyPoint(-s/2, s/2, s/2);
        MyPoint p8 = new MyPoint(-s/2, -s/2, s/2);

        this.tetra = new Tetrahedron(
                new MyPolygon(Color.RED, p1,p2,p3,p4), //order matters
                new MyPolygon(Color.ORANGE, p5,p6,p7,p8),
                new MyPolygon(Color.YELLOW, p2,p1,p5,p6),
                new MyPolygon(Color.GREEN, p1,p5,p8,p4),
                new MyPolygon(Color.BLUE, p2,p6,p7,p3),
                new MyPolygon(Color.PINK, p4,p3,p7,p8));

    }

    private void render() {
        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();
        g.setColor(Color.LIGHT_GRAY); // (new Color (255, 150, 0); (RGB)
        g.fillRect(0,0, WIDTH, HEIGHT); // WIDTH*2, HEIGHT*2);
//        g.fill3DRect(0,0, 200, 200, true);

        tetra.render(g);

        g.dispose();
        bs.show();

    }

    int initialX;
    int initialY;
    ClickType prevMouse = ClickType.Unknown;

    private void update() {
        int x = this.mouse.getMouseX();
        int y = this.mouse.getMouseY();

        if (this.mouse.getButton() == ClickType.LeftClick) {
            int xDiff = x - initialX;
            int yDiff = y - initialY;

            this.tetra.rotate(true, 0, -yDiff/2, -xDiff/2);
        } else if (this.mouse.getButton() == ClickType.RightClick) {
            int xDiff = x - initialX;

            this.tetra.rotate(true, -xDiff/2, 0,0);
        }

        if (this.mouse.isScrollingUp()) {
            // zoom in
            PointConverter.zoomIn();
        } else if (this.mouse.isScrollingDown()) {
            // zoom out
            PointConverter.zoomOut();
        }

        initialX = x;
        initialY = y;
        this.mouse.resetScroll();
    }

}
