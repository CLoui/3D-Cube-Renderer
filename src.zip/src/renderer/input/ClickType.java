package renderer.input;


// scrolclick
public enum ClickType {

    LeftClick,
    RightClick,
    Unknown
}
