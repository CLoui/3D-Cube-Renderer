package renderer.shapes;

import renderer.point.MyPoint;

import java.awt.*;

public class Tetrahedron {

    private MyPolygon[] polygons;
    private Color color;

    public Tetrahedron (Color color, MyPolygon... polygons) {
        this.color = color;
        this.polygons = polygons; //
        this.setPolygonColor();
    }

    public Tetrahedron (MyPolygon... polygons) {
        this.color = Color.WHITE;
        this.polygons = polygons;
    }

    public void render (Graphics g) {
        // draw each polygon individually
        for (MyPolygon poly : this.polygons) {
            poly.render(g);
        }
    }

    private void sortPolygons () {
        MyPolygon.sortPolygons(this.polygons);
    }

    private void setPolygonColor () {
        for (MyPolygon poly : this.polygons) {
            poly.setColor(this.color);
        }
    }

    public void rotate (boolean CW, double xDegrees, double yDegrees, double zDegrees) {
        for (MyPolygon p : this.polygons) {
            p.rotate(CW, xDegrees, yDegrees, zDegrees);
        }
        this.sortPolygons();
    }

}
