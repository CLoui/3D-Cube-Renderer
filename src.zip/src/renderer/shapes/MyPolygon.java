package renderer.shapes;

import renderer.point.MyPoint;
import renderer.point.PointConverter;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MyPolygon {

    private Color color;
    private MyPoint[] points;

    public MyPolygon (Color color, MyPoint... points) { // ... = any number of values in array
        this.color = color;
        this.points = new MyPoint[points.length];

        // copy over values into MyPolygon
        for (int i = 0; i < points.length; i++) {
            MyPoint p = points[i];
            this.points[i] = new MyPoint(p.x, p.y, p.z);
        }
    }

    public MyPolygon (MyPoint... points) {
        this.color = Color.WHITE;
        this.points = new MyPoint[points.length];

        // copy over values into MyPolygon
        for (int i = 0; i < points.length; i++) {
            MyPoint p = points[i];
            this.points[i] = new MyPoint(p.x, p.y, p.z);
        }
    }

    public void render (Graphics g) {
        Polygon poly = new Polygon();

        for (int i = 0; i < this.points.length; i++) {
            Point p = PointConverter.convertPoint(this.points[i]);
            poly.addPoint(p.x, p.y); // add each point to the polygon
        }

        g.setColor(this.color);
        g.fillPolygon(poly);
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void rotate (boolean CW, double xDegrees, double yDegrees, double zDegrees) {
        for (MyPoint p : points) {
            PointConverter.rotateAxisX(p, CW, xDegrees);
            PointConverter.rotateAxisY(p, CW, yDegrees);
            PointConverter.rotateAxisZ(p, CW, zDegrees);
        }

    }

    public static MyPolygon[] sortPolygons (MyPolygon[] polygons) {
        ArrayList<MyPolygon> polygonList = new ArrayList<MyPolygon>();

        for (MyPolygon poly : polygons) {
            polygonList.add(poly);
        }

        Collections.sort(polygonList, (p1, p2) -> p2.getAverageX() - p1.getAverageX() < 0 ? 1 : -1);
//        Collections.sort(polygonList, new Comparator<MyPolygon>() {
//            @Override
//            public int compare(MyPolygon p1, MyPolygon p2) {
//                return p2.getAverageX() - p1.getAverageX() < 0 ? 1 : -1;
//            }
//        });

        for (int i = 0; i < polygons.length; i++) { // toArray
            polygons[i] = polygonList.get(i);
        }

        return polygons;
    }

    public double getAverageX () { //
        double sum = 0;

        for (MyPoint p : this.points) {
            sum += p.x;
        }

        return sum / this.points.length;
    }

}
