package renderer.point;

import renderer.Display;

import java.awt.Point;

public class PointConverter {

    private static double scale = 1;
    private static final double ZOOM_FACTOR = 1.2;

    public static Point convertPoint (MyPoint point3D) {
        double x3D = point3D.y * scale;
        double y3D = point3D.z * scale;
        double depth = point3D.x * scale;
        double[] newVal = scale(x3D, y3D, depth);

        int x2D = (int)(Display.WIDTH / 2 + newVal[0]); // based on the screen, not input
        int y2D = (int)(Display.HEIGHT / 2 - newVal[1]);

        Point point2D = new Point(x2D, y2D);
        return point2D;
    }

    // depth: how far into/out of the screen
    private static double[] scale (double x3D, double y3D, double depth) {
        double dist = Math.sqrt(x3D*x3D + y3D*y3D);
        double depth2 = 25 - depth; // 15
        double theta = Math.atan2(y3D, x3D); // angle of vector
        double localScale = Math.abs(1400/(depth2 + 1400)); //600+800??
        dist *= localScale;

        double[] newVal = new double[2];
        newVal[0] = dist * Math.cos(theta);
        newVal[1] = dist * Math.sin(theta);

        return newVal;

    }

    public static void rotateAxisX (MyPoint p, boolean CW, double degrees) {
        double radius = Math.sqrt(p.y*p.y + p.z*p.z);
        double theta = Math.atan2(p.z, p.y);
        theta += 2 * Math.PI / 360 * degrees * (CW ? -1 : 1); // converted to radians
        p.y = radius * Math.cos(theta);
        p.z = radius * Math.sin(theta);

    }

    public static void rotateAxisY (MyPoint p, boolean CW, double degrees) {
        double radius = Math.sqrt(p.x*p.x + p.z*p.z);
        double theta = Math.atan2(p.x, p.z);
        theta += 2 * Math.PI / 360 * degrees * (CW ? -1 : 1); // converted to radians
        p.z = radius * Math.cos(theta);
        p.x = radius * Math.sin(theta);

    }

    public static void rotateAxisZ (MyPoint p, boolean CW, double degrees) {
        double radius = Math.sqrt(p.x*p.x + p.y*p.y);
        double theta = Math.atan2(p.y, p.x);
        theta += 2 * Math.PI / 360 * degrees * (CW ? -1 : 1); // converted to radians
        p.x = radius * Math.cos(theta);
        p.y = radius * Math.sin(theta);

    }

    public static void zoomIn() {
        scale *= ZOOM_FACTOR;
    }

    public static void zoomOut() {
        scale /= ZOOM_FACTOR;
    }

}
