package renderer.point;

public class MyPoint {

    public double x;
    public double y;
    public double z;

    public MyPoint(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }


}
